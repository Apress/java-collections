interface Predicate {
  boolean predicate(Object element);
}