public class ByteArray {
  public static void main (String args[]) throws Exception {
    byte array1[] = {74, 111, 104, 110};
    System.out.println(new String(array1, "ASCII"));
  }
}