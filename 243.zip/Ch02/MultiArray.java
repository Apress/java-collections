public class MultiArray {
  public static void main (String args[]) {
//    int array[][] = {{1,2,3}, {4,5,6}, {7,8,9}};
//    int []array[] = {{1,2,3}, {4,5,6}, {7,8,9}};
//    System.out.println(array[0][0]);
//    System.out.println(array[1][0]);
//    System.out.println(array[2][0]);
//    System.out.println([0][0]array);
//    System.out.println([1][0]array);
//    System.out.println([2][0]array);
Object events[][] = {
    {new Integer(1452), new String("Italy")},
    {new Integer(1472), new String("baptismOfChrist.jpg")},
    {new Integer(1483), new String("Helicopter")}, 
    {new Integer(1495), new String("Parachute")},
    {new Integer(1503), new String("monaLisa.jpg")},
    {new Integer(1519), new String("France")}
};  }
}